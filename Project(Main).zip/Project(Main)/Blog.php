
<?php
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
include('Connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <style type="text/css"></style>
  <title>Zero Waste</title>
</head>
<body>
  <!-- Header -->
  <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <section class="blog" id="blog">
    <div class="blog-content">
      <header>
        <h1>Our Blog</h1>
      </header>
      <div class="row">
        <div class="left-column">
          <div class="card">
            <h2>Reduce, Reuse, Recycle food waste at home
            </h2>
            <img src="img/food-waste.png" alt="blog " />
            <p>Food waste is the biggest problem faced by our planet.
              Did you know that in the United States alone, approximately 30-40% of food goes to waste each year? That's a staggering amount of food, especially considering that there are millions
               of people around the world who are hungry or food-insecure.The wasted food generates greenhouse gas to reach our plates. </p>
              <a href="https://www.avristech.com/reduce-reuse-recycle-food-waste-at-home/#:~:text=For%20example%2C%20you%20can%20dry,food%20waste%20reaching%20the%20landfill."><button class="btn">Read More</button></a> 
            </div>
          <div class="card">
            <h2>20 Tips To Reduce Plastic Waste</h2>
            <img src="img/plastic.jpg" alt="blog " />
            <p>We all know that plastic is a problem. Despite it having many positive qualities – cheap, easy to make, flexible and accessible – it’s becoming increasingly clear that plastic waste is out of control and causing huge damage to the environment. </p>
              <a href="https://www.futurelearn.com/info/blog/how-to-reduce-plastic-waste"><button class="btn">Read More</button></a> 
          </div>
          <div class="card">
            <h2>10 Tips for Recycling Paper
            </h2>
            <img src="img/paper-recycling-tips.jpg" alt="blog " />
            <p>The easiest way to recycle paper is by creating an at-home recycling center. In one area of your home, set up a few bins or upcycled cardboard boxes that are properly labeled with images of what materials go in them. 
              Recycling paper is important because it helps reduce greenhouse gas emissions that contribute to climate change.
            </p>
              <a href="https://www.goingzerowaste.com/blog/10-tips-for-recycling-paper/"><button class="btn">Read More</button></a> 
          </div>
        </div>
        <div class="right-column">
          <div class="header">
            <h1>Popular Blogs</h1>
          </div> 
          <div class="card">
            <h2>Paper Making</h2>
            <img src="img/paper-making.png" alt="paper-making-img" />
            <p>Recycling paper is an important way to conserve natural resources and reduce waste.
              The process of recycling paper involves breaking down old, used paper into fibers and then re-pulping them to make new paper. 
            </p>
           <a href="https://zerowastehome.blogspot.com/2010/06/paper-making.html"><button class="btn">Read More</button></a> 
          </div>
          <div class="card">
            <h2>Ways to recycle CDs & Tapes</h2>
            <img src="img/tape.jpg" alt="popular" />
            <p>Well, this will vary depending on the state you live in and your local recycling laws. Most CDs + tapes will end up in a landfill where it’s estimated it will take more than 1 million years for a CD to completely decompose</p>
            <button class="btn">Read More</button>
          </div>
          <div class="card">
            <h2>Best Out Of Waste Ideas </h2>
            <img src="img/creative.jpg" alt="popular" />
            <p>There could be several things made from waste materials at home. And these crafts can also help your kids in their classroom projects. Hence the best out of waste craft ideas are most suitable to reuse waste materials and decorate your house.
            </p>
            <button class="btn">Read More</button>

          </div>
          

        </div>
      </div>
    </div>

   <div class="latest">
    <div class="latest-container">
    <header>
      <h1>Latest News</h1>
    </header>
    <div class="latest-content">
      <div class="image">
        <img src="img/sunglass.png" alt="">
      </div>
      <div class="desc">
        <h2>A Pune-based startup claims to have created recycled sunglasses made from packets of chips.</h2>
        <p>Anish Malpani announced the launch of the recycled sunglasses on Twitter, calling it the “most difficult thing” he has ever worked on. In a Pune laboratory, the former finance professional spent two years researching and developing recycled sunglasses made of multi-layered plastics (MLP).</p>
        <a href="https://economictimes.indiatimes.com/news/new-updates/pune-based-startup-claims-to-create-worlds-first-recycled-sunglasses-out-of-potato-chip-packets/articleshow/98126157.cms"><button class="btn">Read More</button></a>
      </div>
    </div>
    
    <div class="latest-content-rev">
      <div class="image">
        <img src="img/car.jpg" alt="">
      </div>
      <div class="desc">
        <h2>Tata Motors opens ELV recycling facility
        </h2>
        <p>Tata Motors, an automobile manufacturer based in Mumbai, India, has opened an end-of-life vehicle (ELV) dismantling facility in Jaipur, India.
          Tata has named the facility Re.Wi.Re, short for “recycle with respect.”.</p>
        <a href="https://www.sciencedaily.com/releases/2023/03/230306143433.html"><button class="btn">Read More</button></a>

      </div>
    </div>

    <div class="latest-content">
      <div class="image">
        <img src="img/sus-plastic.jpg" alt="">
      </div>
      <div class="desc">
        <h2>A wholly sustainable plastics economy is feasible</h2>
        <p>A new study shows what it will take for the plastics industry to become completely sustainable: lots of recycling combined with the use of CO2 from the air and biomass. It is also the image of plastics that need to change.</p>
        <a href="https://www.sciencedaily.com/releases/2023/03/230306143433.html"><button class="btn">Read More</button></a>

      </div>
    </div>
    <div class="latest-content-rev">
      <div class="image">
        <img src="img/kolkata.jpg" alt="">
      </div>
      <div class="desc">
        <h2>11,000 billion tonnes of garbage accumulated in India</h2>
        <p>Kolkata: With emphasis on "circular economy", Union Minister for Environment, Forest, and Climate Change Bhupender Yadav said on Tuesday in Kolkata that there is 11,000 billion tonnes of garbage accumulated in India which has an opportunity to be recycled.
        </p>
        <a href="https://www.sciencedaily.com/releases/2023/03/230306143433.html"><button class="btn">Read More</button></a>

      </div>
    </div>

    </div>

   </div>

    
  </section>









  <section id="footer">
    <div class="footer container">
      <div class="brand">
        <h1><span>Z</span>ero <span>W</span>aste</h1>
      </div>
      <h2>Your Complete zero waste Partner</h2>
      <div class="social-icon">
        <div class="social-item">
          <a href="https://www.facebook.com/profile.php?id=100090248111522"><img
              src="https://img.icons8.com/bubbles/100/000000/facebook-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.instagram.com/zerowaste0/?igshid=YmMyMTA2M2Y%3D"><img
              src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://twitter.com/zerowaste653/status/1625544495122231296?s=46&t=BtinJmemfb4k1XVLMQIUXQ"><img
              src="https://img.icons8.com/bubbles/100/000000/linkedin.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.youtube.com/@zerowaste653"><img
              src="https://img.icons8.com/bubbles/100/000000/youtube.png" /></a>
        </div>

      </div>
    </div>
    <div>
    <p>Copyright © 2023 ZeroWaste. All rights reserved</p>
    </div>
  </section>
  <!-- End Footer -->
  <script src="./app.js"></script>
</body>

</html>