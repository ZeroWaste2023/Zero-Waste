<?php
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
include('Connection.php');
if(isset($_POST["submit"]))
  {
      $Email=$_POST['txtEmail'];
      $Password=$_POST['txtPassword'];
      $check="Select * From User where Email='$Email' and Password='$Password'";
      $result=mysqli_query($connection,$check);
      $num=mysqli_num_rows($result);
      if($num>0)
      {
        $arr=mysqli_fetch_array($result);
        $_SESSION['UserID']=$arr['UserID'];
        $_SESSION['UName']=$arr['UName'];
        $_SESSION['UEmail']=$arr['Email'];
        $_SESSION['Phone']=$arr['Phone'];
         echo"<script>alert('Successfully Login'); </script>";
         echo "<script>window.location.href='indexs.php'</script>";
      }
      else{        
           echo "<script>alert('You dont have an account.');</script>";
           echo "<script>window.location.href='indexs.php'</script>";
      }
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <style type="text/css">
    
  .form
  {
    width: 285px;
    height: 300px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.708)50%,rgba(0, 0, 0, 0.708)50%);
    position: absolute;
    top: 170px;
    left: 1000px;
    transform: translate(0%,-5%);
    border-radius: 10px;
    padding: 25px;
    border: 1px solid #ff7200;
  }

.form h2{
    width: 220px;
    font-family: sans-serif;
    text-align: center;
    color: #ff7200;
    font-size: 22px;
    background-color: #000000;
    border-radius: 10px;
    margin: 2px;
    padding: 8px;
    border-bottom: 1px solid #77ff00;
}
input[type="button"] {
  width: 70%;
  height: 35px;
  margin-top: 20px;
  border: none;
  background-color: #ff7200;
  color: rgb(0, 0, 0);
  font-size: 18px;
}
.btnn{
    width: 200px;
    height: 30px;
    background: #ff7200;
    border: none;
    margin-top: 30px;
    font-size: 18px;
    color:#000000;
    border-radius: 10px;
    cursor: pointer;
    color: #fff;
    transition: 0.4s ease;
}
.btnn:hover{
    background: #fff;
    color: #ff7200;
}
.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}


.signup-box {
  width: 10px;
  height: 20px;
  margin: center;
  background-color: white;
  border-radius: 3px;
  right: 500px;
}

.login-box {
  width: 100px;
  height: 80px;
  margin: auto;
  border-radius: 3px;
  background-color: white;
}

h1 {
  text-align: center;
  padding-top: 15px;
}

h4 {
  text-align: center;
}

form {
  width: 300px;
  margin-left: 20px;
}

form label {
  display: flex;
  margin-top: 20px;
  font-size: 18px;
  color: #ff7200;
}

form input {
  width: 70%;
  height:700;
  padding: 4px;
  border: none;
  border: 1px solid gray;
  border-radius: 6px;
  outline: none;
}
input[type="button"] {
  width: 70%;
  height: 35px;
  margin-top: 20px;
  border: none;
  background-color: #ff7200;
  color: white;
  font-size: 18px;
  
  
}
p {
  text-align: center;
  padding-top: 20px;
  font-size: 15px;
  
}
.para-2 {
  text-align: left;
  color: white;
  font-size: 14px;
  margin-top: -10px;
  width:100%;
  
}
.para-2 a {
  color: #ff7200;
}


</style>
  <title>Zero Waste</title>
</head>

<body>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <!-- Header -->
  <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <!-- End Header -->
  <!-- End Header -->


  <!-- Hero Section  -->
  <section id="hero">
    <div class="hero container">
      <div>
        <h1>Hello, <span></span></h1>
        <h1>Welcome To <span></span></h1>
        <h1>Zero Waste <span></span></h1>
        <a href="#projects" type="button" class="cta">Join Us</a>
        <div class="form">
          <h2>Log In</h2>
          <form method="post">
           
            <label>Email</label>
            <input type="email" name="txtEmail" placeholder="" />
            <label>Password</label>
            <input type="password" name="txtPassword" placeholder="" />
            <button name="submit" type="submit" class="btnn">Login</button>
            <!-- <input type="button" value="Submit" /> -->
            <p class="para-2">
              Don't have an account? <a href="indexs.html">Sign Up</a>
            </p>
          <closeform></closeform></form>
          
        </div>
  </section>
  <!-- End Hero Section  -->

 <!-- Service Section -->
 <section id="services">
    <div class="services container">
      <div class="service-top">
        <h1 class="section-title">How <span>it</span> Works</h1>
        <p>
          Ultimately, the aim of this approach is to create a more sustainable and circular economy, where waste is minimized, resources are conserved, and the environmental impact of our consumption and production patterns is reduced. By adopting this approach, we can create a healthier, more resilient planet for current and future generations.</p>
      </div>
      <div class="service-bottom">
        <div class="service-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/services.png" /></div>
          <h2>You Have Waste</h2>
          <p>Connect to us throught website or App and share the details about your type of waste and we will help you to get your waste used by someone.

          </p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/services.png" /></div>
          <h2>Pick Up</h2>
          <p> Our app offer a convenient and environmentally friendly way to dispose of waste. By using this apps, users can save time and effort while also helping to reduce the amount of waste in our communities.

          </p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/services.png" /></div>
          <h2>Collect</h2>
          <p> Our app  can help streamline the waste collection process, reduce delays and missed pickups, and ensure that waste is collected efficiently and safely. It can also help to educate users on proper waste disposal practices.</p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/services.png" /></div>
          <h2>Reduce</h2>
          <p>Offer a platform for sharing and donating items: Our app provide a platform for users to share and donate items they no longer need, such as clothing, food etc. This can help prevent these items from ending up in landfills and can also provide affordable options for others</p>
          
        </div>
      </div>
    </div>
  </section>
  <!-- End Service Section -->

  <section id="services">
    <div class="services container">
      <h1 class="section-title">About <span>Us</span></h1>
      <div class="service-bottom">
        <div class="service-item">
          <div class="icon"><img src="img/billu di-modified.png"/></div>
          <h2>May Thazin</h2>
          <p>Nature is the Future.</p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="img/sonia-modified.png "/></div>
          <h2>Harsh Trivedi</h2>
          <p> We are not above nature, We are a part of it.</p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="img/harsh-modified.png "/></div>
          <h2>Collect</h2>
          <p>Recycling take a little effort on your part but makes a big difference to the world.</p>
        </div>
        <div class="service-item">
          <div class="icon"><img src="img/cp-modified.png "/></div>
          <h2>Reduce</h2>
          <p>If you care about the environment and how it will affect the mankind then recycling should not take a second thought.</p>
          
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Section -->
  <section id="contact">
    <div class="contact container">
      <div>
        <h1 class="section-title">Contact <span>info</span></h1>
      </div>
      <div class="contact-items">
        <div class="contact-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/phone.png" /></div>
          <div class="contact-info">
            <h1>Phone</h1>
            <h2>+91 8488957457</h2>
            <h2></h2>
          </div>
        </div>
        <div class="contact-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/new-post.png" /></div>
          <div class="contact-info">
            <h1>Email</h1>
            <h2>zerowaste653@gmail.com</h2>
            
          </div>
        </div>
        <div class="contact-item">
          <div class="icon"><img src="https://img.icons8.com/bubbles/100/000000/map-marker.png" /></div>
          <div class="contact-info">
            <h1>Address</h1>
            <h2>Marwadi University, Rajkot, India</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Contact Section -->

  <!-- Footer -->
  <section id="footer">
    <div class="footer container">
      <div class="brand">
        <h1><span>Z</span>ero <span>W</span>aste</h1>
      </div>
      <h2>Your Complete zero waste Partner</h2>
      <div class="social-icon">
        <div class="social-item">
          <a href="https://www.facebook.com/profile.php?id=100090248111522"><img src="https://img.icons8.com/bubbles/100/000000/facebook-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.instagram.com/zerowaste0/?igshid=YmMyMTA2M2Y%3D"><img src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://twitter.com/zerowaste653/status/1625544495122231296?s=46&t=BtinJmemfb4k1XVLMQIUXQ"><img src="https://img.icons8.com/bubbles/100/000000/linkedin.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.youtube.com/@zerowaste653"><img src="https://img.icons8.com/bubbles/100/000000/youtube.png" /></a>
        </div>
         
        </div>
      </div>
      <p>Copyright © 2023 ZeroWaste. All rights reserved</p>
    </div>
  </section>
  <!-- End Footer -->
  <script src="./app.js"></script>
</body>

</html>