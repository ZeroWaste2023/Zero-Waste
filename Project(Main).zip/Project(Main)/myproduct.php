<?php 
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
    include('Connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
        integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Zero Waste</title>
</head>
<body>
    <form action="sell.php" method="post" enctype="multipart/form-data">
    <fieldset>
      <legend>Sell Information</legend>
          <table>
              <tr>
                <td>
                  <?php
                      $Email= $_SESSION['UEmail'];
                      $query="SELECT * FROM Sell where Email='$Email'";
                      $ret=mysqli_query($connection,$query);
                      $num_results=mysqli_num_rows($ret);
                      if ($num_results==0) {
                           echo "<h2>No Record Found</h2>";
                       }
                      else{
                           echo "<table width='100%' cellpadding='8'>";
                           echo "<tr>";
                           echo "<th algin='left'>Name</th>";
                           echo "<th algin='left'>Pic </th>";
                           echo "<th algin='left'>Price</th>";
                           echo "<th align='left'>Action</th>";
                           echo "</tr>";
                              for($i=0;$i<$num_results;$i++)
                              {
                                $row=mysqli_fetch_array($ret);
                                $Email=$row["Email"];
                                $Name=$row["Name"];
                                $Pimage=$row['Pic'];
                                  echo "<tr>";
                                  echo "<td>".$row["Name"]."</td>";
                                  echo "<td><img src='$Pimage' width='200px' height='200px'/></td>";
                                  echo "<td>".$row["Price"]."</td>";
                                  
                                  echo "<td><a class='btn' href='deleteproduct.php?Name=$Name'>Delete</a></td>";
                                  echo "</tr>";
                                }
                                echo "</table>";        }
                            ?>
                        </td>
                    </tr>
                </table>
            </fieldset>
    </form>
    <script src="script.js"></script>
</body>
</html>