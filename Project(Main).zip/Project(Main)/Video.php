<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <style type="text/css"></style>
  <title>Zero Waste</title>
</head>
<body>
  <!-- Header -->
  <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
    <section id="videos">
      <div class="hed">
        <header>
          <h1>Our videos</h1>
        </header>
      </div>
      <div class="videos ">
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>

        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container"><iframe src="https://www.youtube.com/embed/k3YnHzglqx8"
              title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container"><iframe src="https://www.youtube.com/embed/k3YnHzglqx8"
              title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>

      </div>
      <div class="videos" id="part1">
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>

        <div class="videos-item">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/k3YnHzglqx8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container"><iframe src="https://www.youtube.com/embed/k3YnHzglqx8"
              title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>
        <div class="videos-item">
          <div class="video-container"><iframe src="https://www.youtube.com/embed/k3YnHzglqx8"
              title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;
           web-share" allowfullscreen></iframe>
          </div>
          <div class="desc">
            <p>This is video description</p>
          </div>
        </div>

      </div>
     



    </section>


    <section id="footer">
      <div class="footer container">
        <div class="brand">
          <h1><span>Z</span>ero <span>W</span>aste</h1>
        </div>
        <h2>Your Complete zero waste Partner</h2>
        <div class="social-icon">
          <div class="social-item">
            <a href=""><img src="https://img.icons8.com/bubbles/100/000000/facebook-new.png" /></a>
          </div>
          <div class="social-item">
            <a href=""><img src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" /></a>
          </div>
          <div class="social-item">
            <a href=""><img src="https://img.icons8.com/bubbles/100/000000/linkedin.png" /></a>
          </div>
          <div class="social-item">
            <a href="#"><img src="https://img.icons8.com/bubbles/100/000000/youtube.png" /></a>
          </div>

        </div>
      </div>
      <p>Copyright © 2023 ZeroWaste. All rights reserved</p>
      </div>
    </section>
    <!-- End Footer -->
    <script src="./app.js"></script>
</body>

</html>