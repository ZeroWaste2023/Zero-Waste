<?php
    session_start();
    ini_set('display_errors', 1); 
    ini_set('display_startup_errors', 1); 
    error_reporting(E_ALL);
    include('Connection.php');
    if(isset($_REQUEST['Name'])){
        $Email= $_SESSION['UEmail'];
        $Name=$_REQUEST['Name'];
        $query="DELETE FROM Sell WHERE Email='$Email' and Name='$Name'";
        $result=mysqli_query($connection,$query);
        if ($result) {
            echo"<script>alert('Product Record Delete Successful');</script>";
            echo "<script>window.location.href='Sell.php';</script>";
        }
        else
        {
            echo"<script>alert('Product Record cannot delete');</script>";
            echo "<script> window.location.href='Sell.php';</script>";
        }
    }
    else{
        echo "<script>alert('Nothing Found')</script>";
        echo "<script> window.location='Sell.php';</script>";
    }
?>