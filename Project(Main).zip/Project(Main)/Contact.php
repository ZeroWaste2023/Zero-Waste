<?php
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
include('Connection.php');
if(isset($_POST["submit"]))
  {
      $Name=$_POST['txtUserName'];
      $Email=$_POST['txtEmail'];
      $Phone=$_POST['txtPhone'];
      $Message=$_POST['txtMessage'];
       $num=1;
      if($num>0)
      {
           $check="insert into Donate (UName,Email,Phone,Message) values('$Name','$Email','$Phone','$Message')";
           $result=mysqli_query($connection,$check);
             
           echo "<script>alert('We will contact u soon');</script>";
           echo "<script>window.location.href='Contact.php'</script>";
      }
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <style type="text/css">
    
  .form
  {
    width: 285px;
    height: 505px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.708)50%,rgba(0, 0, 0, 0.708)50%);
    position: absolute;
    top: 150px;
    left: 1000px;
    transform: translate(0%,-5%);
    border-radius: 10px;
    padding: 25px;
    border: 1px solid #ff7200;
  }

.form h2{
    width: 220px;
    font-family: sans-serif;
    text-align: center;
    color: #ff7200;
    font-size: 22px;
    
    border-radius: 10px;
    margin: 2px;
    padding: 8px;
    border-bottom: 1px solid #77ff00;
}


.signup-box {
  width: 10px;
  height: 20px;
  margin: center;
  background-color: white;
  border-radius: 3px;
  right: 500px;
}

.login-box {
  width: 100px;
  height: 80px;
  margin: auto;
  border-radius: 3px;
  background-color: white;
}

h1 {
  text-align: center;
  padding-top: 15px;
 
}

h4 {
  text-align: center;
}

form {
  width: 300px;
  margin-left: 20px;
}

form label {
  display: flex;
  margin-top: 20px;
  font-size: 18px;
   color: #ff7200;
}

form input {
  width: 70%;
  height:700;
  padding: 4px;
  border: none;
  border: 1px solid gray;
  border-radius: 6px;
  outline: none;
}
input[type="button"] {
  width: 70%;
  height: 35px;
  margin-top: 20px;
  border: none;
  background-color: #ff7200;
  color: rgb(0, 0, 0);
  font-size: 18px;
}
.btnn{
    width: 200px;
    height: 30px;
    background: #ff7200;
    border: none;
    margin-top: 30px;
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color: #fff;
    transition: 0.4s ease;
}
.btnn:hover{
    background: #fff;
    color: #ff7200;
}
.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}

p {
  text-align: center;
  padding-top: 20px;
  font-size: 15px;
}
.para-2 {
  text-align: left;
  color: white;
  font-size: 14px;
  margin-top: -10px;
  width:100%;
  
}
.para-2 a {
  color: #ff7200;
}
.whatsapp_float{
  position:fixed;
  bottom:40px;
  right:20px;
}
</style>
  <title>Zero Waste</title>
</head>

<body>
  <!-- Header -->
  <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <div class="whatsapp_float">
    <a href="https://wa.me/918488957457" target="_blank"><img src='./img/whatsapp.png' width="50px" class="whatsapp_float_btn"/></a>
  </div>
  <section id="hero">
    <div class="hero container">
      
      <div>
        <h1>Hello,<span></span></h1>
        <h1>Welcome To<span></span></h1>
        <h1>Zero Waste<span></span></h1>
        <a href="#projects" type="button" class="cta">Join Us</a>
        <?php
        if(!isset($_SESSION['UserID']))
         {
          ?>
          <div class="form">
          <h2>Contact US</h2>
          <form action="" method="post">
            <label>User Name</label>
            <input type="text" name="txtUserName" placeholder="" />
            <label>Email</label>
            <input type="email" name="txtEmail" placeholder="" />
            <label>Phone</label>
            <input type="text" name="txtPhone" placeholder="" />
            <label>Message</label>
            <input type="textarea" name="txtMessage" placeholder="" />
            <button class="btnn" name="submit" type="submit" >Contact</button>
          </form>
        </div>
       <?php 
       }
       ?>
      </body>
    </html>
  </section>
  <section id="footer">
    <div class="footer container">
      <div class="brand">
        <h1><span>Z</span>ero <span>W</span>aste</h1>
      </div>
      <h2>Your Complete zero waste Partner</h2>
      <div class="social-icon">
        <div class="social-item">
          <a href="https://www.facebook.com/profile.php?id=100090248111522"><img src="https://img.icons8.com/bubbles/100/000000/facebook-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.instagram.com/zerowaste0/?igshid=YmMyMTA2M2Y%3D"><img src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://twitter.com/zerowaste653/status/1625544495122231296?s=46&t=BtinJmemfb4k1XVLMQIUXQ"><img src="https://img.icons8.com/bubbles/100/000000/linkedin.png" /></a>
        </div>
        <div class="social-item">
          <a href="https://www.youtube.com/@zerowaste653"><img src="https://img.icons8.com/bubbles/100/000000/youtube.png" /></a>
        </div>
         
        </div>
      </div>
      <p>Copyright © 2023 ZeroWaste. All rights reserved</p>
    </div>
  </section>
  <!-- End Footer -->
  <script src="./app.js"></script>
</body>

</html>