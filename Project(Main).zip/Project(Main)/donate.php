<?php
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
include('Connection.php');
if(isset($_POST["submit"]))
  {
      $Name=$_POST['txtName'];
      $Things=$_POST['txtdonate'];
      $Address=$_POST['txtaddress'];
      $Phone=$_POST['txtnumber'];
      $num=1;
      if($num>0)
      {
        $check="insert into Donate (Name,Things,Address,Phone) values('$Name','$Things','$Address','$Phone')";
        $result=mysqli_query($connection,$check);
          
        echo "<script>alert('Thank you for your donation');</script>";
        echo "<script>window.location.href='donate.php'</script>";
      }
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <style type="text/css">
    
  .form
  {
    width: 285px;
    height: 505px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.708)50%,rgba(0, 0, 0, 0.708)50%);
    position: absolute;
    top: 150px;
    left: 1000px;
    transform: translate(0%,-5%);
    border-radius: 10px;
    padding: 25px;
    border: 1px solid #ff7200;
  }

.form h2{
    width: 220px;
    font-family: sans-serif;
    text-align: center;
    color: #ff7200;
    font-size: 22px;
    
    border-radius: 10px;
    margin: 2px;
    padding: 8px;
    border-bottom: 1px solid #77ff00;
}
.signup-box {
  width: 10px;
  height: 20px;
  margin: center;
  background-color: white;
  border-radius: 3px;
  right: 500px;
}

.login-box {
  width: 100px;
  height: 80px;
  margin: auto;
  border-radius: 3px;
  background-color: white;
}

h1 {
  text-align: center;
  padding-top: 15px;
 
}

h4 {
  text-align: center;
}

form {
  width: 300px;
  margin-left: 20px;
}

form label {
  display: flex;
  margin-top: 20px;
  font-size: 18px;
   color: #ff7200;
}

form input {
  width: 70%;
  height:700;
  padding: 4px;
  border: none;
  border: 1px solid gray;
  border-radius: 6px;
  outline: none;
}
input[type="button"] {
  width: 70%;
  height: 35px;
  margin-top: 20px;
  border: none;
  background-color: #ff7200;
  color: rgb(0, 0, 0);
  font-size: 18px;
}
.btnn{
    width: 200px;
    height: 30px;
    background: #ff7200;
    border: none;
    margin-top: 30px;
    font-size: 18px;
    border-radius: 10px;
    cursor: pointer;
    color: #fff;
    transition: 0.4s ease;
}
.btnn:hover{
    background: #fff;
    color: #ff7200;
}
.btnn a{
    text-decoration: none;
    color: #000;
    font-weight: bold;
}

p {
  text-align: center;
  padding-top: 20px;
  font-size: 15px;
}
.para-2 {
  text-align: left;
  color: white;
  font-size: 14px;
  margin-top: -10px;
  width:100%;
  
}
.para-2 a {
  color: #ff7200;
}

</style>
  <title>Zero Waste</title>
</head>

<body>
  <!-- Header -->
  <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <!-- End Header -->
  <!-- Hero Section  -->
  <section id="hero">
    <div class="hero container">
      <div>
        <h1>Hello, <span></span></h1>
        <h1>Welcome To <span></span></h1>
        <h1>Zero Waste <span></span></h1>
        <div class="form">
            <h2>Donate Us</h2>
            <form action="" method="post">
              <label>Your Name</label>
              <input type="text" name="txtName" placeholder="" />
              <label>What to donate?</label>
              <input type="text" name="txtdonate" placeholder="eg. Books, food, clothes" />
              <label>Address</label>
              <input type="text" name="txtaddress" placeholder="" />
              <label>Phone Number</label>
              <input type="text" name="txtnumber"  placeholder="" />
              <button class="btnn" name="submit">Donate</button>
            </form>
          </div>
      </body>
    </html>
</section>  
  <script src="./app.js"></script>
</body>

</html>