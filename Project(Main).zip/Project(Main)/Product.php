<?php 
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
include('Connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Zero Waste</title>
  <style>
    .display{
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

  </style>
</head>
  <body>

  <?php
            $searchdata="SELECT * FROM Sell ORDER BY Name";
            $ret=mysqli_query($connection,$searchdata);
            $num_result=mysqli_num_rows($ret);
            echo "<table>";
            for($c=0; $c<$num_result;$c+=3)
              {
                $class="SELECT * FROM Sell order by Name LIMIT $c,3";
                $retp=mysqli_query($connection,$class);
                $num_result1=mysqli_num_rows($retp);
                echo "<tr border='1'>";
                for($d=0;$d<$num_result1;$d++)
                  {
                    $row=mysqli_fetch_array($retp);
                     ?>
                    <td>
                       <div class="display">
                           <img src='<?php echo $row['Pic'];  ?>' style="width:100%">
                       </div>
                       <div>
                       <br>
                       <b><h1>Buy <?php echo $row['Name']; ?> </h1> </b>
                       <b class="price"><?php echo $row['Price']; ?></b>
                       <b><h1>contact <?php echo $row['Phone']; ?></h1></b>
                       <br> 
                       </div>
                      </a>
                    </td>
                 <?php
              }
                echo "</tr>";  
            }
            echo "</table>";

            ?>
            </body>
</html>

