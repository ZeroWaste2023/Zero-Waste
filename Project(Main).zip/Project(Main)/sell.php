<?php 
session_start();
ini_set('display_errors', 1); 
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL);
    include('Connection.php');
    if(isset($_SESSION['UName']))
    {
    if(isset($_POST['btnsubmit']))
     {
        $Email=  $_SESSION['UEmail'];
    	$Name=$_POST['txtProductName'];
    	$Phone=$_SESSION['Phone'];
    	$Price=$_POST['txtPrice'];
        $image=$_FILES['txtpath']['name'];
        $folder="img/";
        if($image)
        {
            $filename=$folder."_".$image;
            $copied=copy($_FILES['txtpath']['tmp_name'],$filename);
            if(!$copied)
            {
                exit("Problem occured.");
            }
        }
        $check="Select * From Sell where Name='$Name' and Email='$Email'";
        $result=mysqli_query($connection,$check);
        $rows=mysqli_num_rows($result);
        if($rows<1)
        {
           $insert="insert into Sell (Email,Name,Phone,Pic,Price) values('$Email','$Name','$Phone','$filename','$Price')";
           $check=mysqli_query($connection,$insert);
           if($check)
           {
            echo "<script>alert('Your Products displayed successfully')</script>";
           }
        }
        if($rows==1)
        {
            echo "<script>alert('You already have that product')</script>";
        }

     }
    }
       else{
            echo "<script>alert('Please create account first')</script>";
            echo "<script>window.location.href='indexs.php'</script>";
        }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
        integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Zero Waste</title>
</head>
<body>
    <!-- Header -->
    <section id="header">
    <div class="header container">
      <div class="nav-bar">
        <div class="brand">
          <a href="#hero">
            <h1><span>Z</span>ero <span>W</span>aste</h1>
          </a>
        </div>
        <div class="nav-list">
          <div class="hamburger">
            <div class="bar"></div>
          </div>
          <ul>
            <li><a href="indexs.php" data-after="Home">Home</a></li>
            <li><a href="donate.php" data-after="Service">Donate</a></li>
            <li><a href="Video.php" data-after="Projects">Video</a></li>
            <li><a href="Blog.php" data-after="Projects">Blog</a></li>

            <?php 
            if(isset($_SESSION['UserID']))
            {
              ?>
                          <li><a href="Sell.php" data-after="Projects">Sell</a></li>
              <?php
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  </section>
    <form action="sell.php" method="post" enctype="multipart/form-data">
    <section class="sell" id="sell">
        <div class="sell-container">
            <div class="form">
                <div class="title">
                    <h2>Sell Your Product</h2>
                </div>

                <div class="input_field" id="product-name">
                    <label>Product-Name</label>
                    <input type="text" class="input" name="txtProductName" placeholder="Please Enter Your Product Name">
                </div>

                <div class="input_field" id="price">
                    <label>Price</label>
                    <input name="txtPrice" placeholder="Please Enter your Price" type="text" class="input" >
                </div>

                <div class="input_field" id="product-name">
                    <label>Picture</label>
                    <input type="file" id="file" name='txtpath'>
                </div>
                    <button class="btnn" name="btnsubmit">Sell</button>
                    <p class="para-2">
             <label>Wanna see your products.Click here<a href="myproduct.php">Products</a></label>
            </p>
                </div>
                
        </div>
    </section>
    
    </form>
    <section id="footer">
        <div class="footer container">
            <div class="brand">
                <h1><span>Z</span>ero <span>W</span>aste</h1>
            </div>
            <h2>Your Complete zero waste Partner</h2>
            <div class="social-icon">
                <div class="social-item">
                    <a href="https://www.facebook.com/profile.php?id=100090248111522"><img
                            src="https://img.icons8.com/bubbles/100/000000/facebook-new.png" /></a>
                </div>
                <div class="social-item">
                    <a href="https://www.instagram.com/zerowaste0/?igshid=YmMyMTA2M2Y%3D"><img
                            src="https://img.icons8.com/bubbles/100/000000/instagram-new.png" /></a>
                </div>
                <div class="social-item">
                    <a href="https://twitter.com/zerowaste653/status/1625544495122231296?s=46&t=BtinJmemfb4k1XVLMQIUXQ"><img
                            src="https://img.icons8.com/bubbles/100/000000/linkedin.png" /></a>
                </div>
                <div class="social-item">
                    <a href="https://www.youtube.com/@zerowaste653"><img
                            src="https://img.icons8.com/bubbles/100/000000/youtube.png" /></a>
                </div>
            </div>
        </div>
        <div>
            <p>Copyright © 2023 ZeroWaste. All rights reserved</p>
        </div>
    </section>
    <!-- End Footer -->
    <script src="script.js"></script>
</body>
</html>