<?php

   $host="localhost";
   $user="root";
   $password="";
   $database="ZeroWastes";
   $connection=mysqli_connect($host,$user,$password,$database);
?>